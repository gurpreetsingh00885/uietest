//using materializecss..
  $(document).ready(function() {
    $('select').material_select();
  });



$('select').material_select('destroy');
